import { sendTextMessage, sendTemplateMessage } from '@/lib/whatsapp/meta-api';
import type { InteractiveMessagePayload } from '@/lib/whatsapp/interactive';
import {
  engineSendInteractiveButtons,
  engineSendInteractiveList,
} from '@/lib/flows/meta-send';
import { resolveWhatsAppConnection } from '@/lib/whatsapp/connection-resolver';
import {
  phoneVariants,
  isRecipientNotAllowedError,
} from '@/lib/whatsapp/phone-utils';
import { resolveContactSendTarget } from '@/lib/whatsapp/wa-identity';
import { assertConversationInAccount } from '@/lib/whatsapp/conversation-scope';
import { AutomationTemplateSendError } from './template-send-error';
import { supabaseAdmin } from './admin-client';
import type { PreparedTemplateMessage } from '@/lib/message-preparation/types';
import type { SendTemplateMessageArgs } from '@/lib/whatsapp/meta-api';
import { renderTemplateBody } from '@/lib/whatsapp/template-body';

// ------------------------------------------------------------
// Automation-side Meta sender.
//
// Mirrors the logic in src/app/api/whatsapp/send/route.ts but uses
// the service-role client (engine has no cookies) and accepts the
// user / conversation / contact identifiers the engine already has
// on hand. Kept here (rather than refactoring the user-facing send
// route) to avoid risk to the working manual-send path — they can
// converge in a later refactor.
// ------------------------------------------------------------

interface SendTextArgs {
  onBeforeMeta?: () => Promise<void>;
  onMetaAccepted?: (messageId: string) => Promise<void>;
  /** Account-level tenancy key. Drives contact + whatsapp_config
   *  lookups so an automation authored by user A still sends through
   *  the WhatsApp number user B saved on the same account. */
  accountId: string;
  /** Original author of the automation/flow — used for INSERT audit
   *  columns (messages.sender_id-ish) and for resolving the agent's
   *  identity in logs. Not consulted for tenancy. */
  userId: string;
  conversationId: string;
  contactId: string;
  text: string;
}

interface SendTemplateArgs {
  onBeforeMeta?: () => Promise<void>;
  onMetaAccepted?: (messageId: string) => Promise<void>;
  accountId: string;
  userId: string;
  conversationId: string;
  contactId: string;
  templateName: string;
  connectionId: string;
  preparedTemplate: PreparedTemplateMessage;
  templatePayload: NonNullable<SendTemplateMessageArgs['templatePayload']>;
  language?: string;
}

export async function engineSendText(
  args: SendTextArgs
): Promise<{ whatsapp_message_id: string }> {
  return sendViaMeta({ ...args, kind: 'text' });
}

export async function engineSendTemplate(
  args: SendTemplateArgs
): Promise<{ whatsapp_message_id: string }> {
  return sendViaMeta({ ...args, kind: 'template' });
}

interface SendInteractiveArgs {
  onBeforeMeta?: () => Promise<void>;
  onMetaAccepted?: (messageId: string) => Promise<void>;
  accountId: string;
  userId: string;
  conversationId: string;
  contactId: string;
  payload: InteractiveMessagePayload;
}

/**
 * Send an interactive (reply-buttons or list) message from the
 * automation engine.
 *
 * Delegates to the Flows interactive senders
 * (`engineSendInteractiveButtons` / `engineSendInteractiveList`), which
 * already own the account-scoped lookup, phone-variant retry, and the
 * `messages` insert with `interactive_payload` + `sender_type='bot'`.
 * Both engines want identical behaviour here, so there's one
 * implementation rather than a second hand-rolled copy that could drift.
 */
export async function engineSendInteractive(
  args: SendInteractiveArgs
): Promise<{ whatsapp_message_id: string }> {
  const { payload, accountId, userId, conversationId, contactId } = args;
  const common = {
    accountId,
    userId,
    conversationId,
    contactId,
    onBeforeMeta: args.onBeforeMeta,
    onMetaAccepted: args.onMetaAccepted,
  };
  if (payload.kind === 'buttons') {
    return engineSendInteractiveButtons({
      ...common,
      bodyText: payload.body,
      headerText: payload.header,
      footerText: payload.footer,
      buttons: payload.buttons,
    });
  }
  return engineSendInteractiveList({
    ...common,
    bodyText: payload.body,
    buttonLabel: payload.button_label,
    headerText: payload.header,
    footerText: payload.footer,
    sections: payload.sections,
  });
}

type SendInput =
  (SendTextArgs & { kind: 'text' }) | (SendTemplateArgs & { kind: 'template' });

async function sendViaMeta(
  input: SendInput
): Promise<{ whatsapp_message_id: string }> {
  const db = supabaseAdmin();

  // Scope the contact + config lookups by account_id, not user_id.
  // The engine uses the service-role client (bypassing RLS); without
  // this filter, an authenticated user could fire their own
  // automations against another tenant's contact UUID and send via
  // their own WhatsApp config to that contact's phone. The 017
  // migration moved both tables to account-scoped tenancy, so the
  // check is the same defense-in-depth as before, just keyed on the
  // new tenancy column.
  const { data: contact, error: contactErr } = await db
    .from('contacts')
    .select('id, phone, wa_user_id')
    .eq('id', input.contactId)
    .eq('account_id', input.accountId)
    .maybeSingle();
  if (contactErr || !contact) {
    if (input.kind === 'template')
      throw new AutomationTemplateSendError(
        contactErr
          ? 'template_recipient_lookup_failed'
          : 'template_recipient_not_owned',
        Boolean(contactErr)
      );
    throw new Error('contact not found for this account');
  }

  // Same for the conversation the message lands in — see
  // conversation-scope.ts (GHSA-m4fx-g6pr-hrw8).
  await assertConversationInAccount(db, input.conversationId, input.accountId);

  // Phone number, or the business-scoped user ID when Meta has never
  // given us a number for this customer (issue #519).
  const sendTarget = resolveContactSendTarget(contact);
  if (!sendTarget) {
    if (input.kind === 'template')
      throw new AutomationTemplateSendError(
        'template_recipient_unaddressable',
        false
      );
    throw new Error('contact has no usable WhatsApp address');
  }
  const sanitized = sendTarget.target;

  const config = await resolveWhatsAppConnection(db, {
    accountId: input.accountId,
    conversationId: input.conversationId,
    ...(input.kind === 'template' ? { connectionId: input.connectionId } : {}),
  });
  if (input.kind === 'template' && config.status !== 'connected')
    throw new AutomationTemplateSendError(
      'template_connection_not_connected',
      false
    );
  const accessToken = config.accessToken;

  const attempt = async (phone: string): Promise<string> => {
    await input.onBeforeMeta?.();
    if (input.kind === 'template') {
      try {
        const r = await sendTemplateMessage({
          phoneNumberId: config.phoneNumberId,
          accessToken,
          to: phone,
          templateName: input.templateName,
          language: input.language,
          templatePayload: input.templatePayload,
        });

        return r.messageId;
      } catch (error) {
        const metaError = error as {
          name?: string;
          message?: string;
          code?: number;
          subcode?: number;
          details?: string;
          userMessage?: string;
          fbtraceId?: string;
          httpStatus?: number;
        };

        console.error('Meta template send failed', {
          error: {
            name: metaError.name,
            code: metaError.code,
            subcode: metaError.subcode,
            fbtraceId: metaError.fbtraceId,
            httpStatus: metaError.httpStatus,
          },

          templateName: input.templateName,
          connectionId: input.connectionId,
          phoneNumberId: config.phoneNumberId,

          componentShape: input.templatePayload?.components?.map(
            (component) => ({
              type: component.type,
              parameterCount:
                'parameters' in component && Array.isArray(component.parameters)
                  ? component.parameters.length
                  : 0,
            })
          ),
        });

        throw error;
      }
    }
    const r = await sendTextMessage({
      phoneNumberId: config.phoneNumberId,
      accessToken,
      to: phone,
      text: input.text,
    });
    return r.messageId;
  };

  // Semantic templates use the validated contact destination. Historical
  // text sends retain their existing phone-variant behavior.
  const variants =
    sendTarget.isPhone && input.kind !== 'template'
      ? phoneVariants(sanitized)
      : [sanitized];
  let workingPhone = sanitized;
  let waMessageId = '';
  let lastError: unknown = null;
  for (const v of variants) {
    try {
      waMessageId = await attempt(v);
      workingPhone = v;
      lastError = null;
      break;
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (!isRecipientNotAllowedError(msg)) throw err;
      lastError = err;
    }
  }
  if (lastError) throw lastError;
  await input.onMetaAccepted?.(waMessageId);

  if (sendTarget.isPhone && workingPhone !== sanitized) {
    await db
      .from('contacts')
      .update({ phone: workingPhone })
      .eq('id', contact.id);
  }

  // Persist the sent message so it appears in the inbox with a real
  // Meta message id. sender_type='bot' distinguishes automation sends
  // from manual agent sends.
  const content_type = input.kind === 'template' ? 'template' : 'text';
  // Templates persist the substituted body, same as the manual and
  // public-API send paths. This was unconditionally null, so every
  // automation template send rendered as an empty bubble (issue #483).
  const content_text =
    input.kind === 'text'
      ? input.text
      : renderTemplateBody(
          input.preparedTemplate.template.body_text,
          (
            input.templatePayload.components?.find(
              (component) => component.type === 'body'
            )?.parameters ?? []
          ).map((parameter) =>
            parameter.type === 'text' ? parameter.text : ''
          )
        );
  const template_name = input.kind === 'template' ? input.templateName : null;

  const { error: msgErr } = await db.from('messages').insert({
    conversation_id: input.conversationId,
    sender_type: 'bot',
    content_type,
    content_text,
    template_name,
    message_id: waMessageId,
    status: 'sent',
  });
  if (msgErr) {
    // Meta already has the message; record the DB error but don't pretend
    // the send failed. The engine wraps this in a log line.
    if (input.kind === 'template')
      throw new AutomationTemplateSendError(
        'meta_sent_message_persistence_failed',
        false
      );
    throw new Error(`sent to Meta but DB insert failed: ${msgErr.message}`);
  }

  const { error: previewError } = await db
    .from('conversations')
    .update({
      last_message_text:
        input.kind === 'template'
          ? (content_text ?? `[template:${input.templateName}]`)
          : input.text,
      last_message_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq('id', input.conversationId)
    .eq('account_id', input.accountId);
  if (previewError && input.kind === 'template')
    throw new AutomationTemplateSendError(
      'meta_sent_conversation_persistence_failed',
      false
    );

  return { whatsapp_message_id: waMessageId };
}
