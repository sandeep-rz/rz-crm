import { describe, expect, it } from 'vitest';
import {
  stepsRequireWhatsAppConnection,
  validatePmsPropertyTimezonesForActivation,
  validateStepsForActivation,
  validateTriggerForActivation,
  validateWhatsAppConnectionForActivation,
} from './validate';

function propertyDb(
  rows: Array<Record<string, unknown>>,
  error: unknown = null
) {
  const query = {
    select: () => query,
    eq: () => query,
    in: () => query,
    then: (resolve: (value: unknown) => unknown) =>
      Promise.resolve({ data: rows, error }).then(resolve),
  };
  return { from: () => query } as never;
}

describe('validateStepsForActivation', () => {
  it('rejects empty or missing step lists', () => {
    expect(validateStepsForActivation([])).toEqual([
      { path: 'steps', message: 'active automations need at least one step' },
    ]);
    expect(validateStepsForActivation(undefined as unknown as never[])).toEqual(
      [{ path: 'steps', message: 'active automations need at least one step' }]
    );
  });

  it('passes a fully-populated step set', () => {
    const issues = validateStepsForActivation([
      { step_type: 'send_message', step_config: { text: 'hi' } },
      {
        step_type: 'wait',
        step_config: { amount: 5, unit: 'minutes' },
      },
      { step_type: 'add_tag', step_config: { tag_id: 'tag-uuid' } },
      { step_type: 'close_conversation', step_config: {} },
    ]);
    expect(issues).toEqual([]);
  });

  it('flags every required field that is missing', () => {
    const issues = validateStepsForActivation([
      { step_type: 'send_message', step_config: { text: '  ' } },
      { step_type: 'send_template', step_config: {} },
      { step_type: 'add_tag', step_config: { tag_id: '' } },
    ]);
    expect(issues.map((i) => i.path)).toEqual([
      'steps[0].text',
      'steps[1].template_id',
      'steps[2].tag_id',
    ]);
  });

  it('checks wait amount and unit boundaries', () => {
    const issues = validateStepsForActivation([
      { step_type: 'wait', step_config: { amount: 0, unit: 'minutes' } },
      { step_type: 'wait', step_config: { amount: 5, unit: 'seconds' } },
      { step_type: 'wait', step_config: { amount: -1, unit: 'hours' } },
      {
        step_type: 'wait',
        step_config: { amount: Number.POSITIVE_INFINITY, unit: 'days' },
      },
    ]);
    expect(issues.map((i) => i.path)).toEqual([
      'steps[0].amount',
      'steps[1].unit',
      'steps[2].amount',
      'steps[3].amount',
    ]);
  });

  it('validates webhook URLs', () => {
    const good = validateStepsForActivation([
      {
        step_type: 'send_webhook',
        step_config: { url: 'https://hooks.example.com/in' },
      },
    ]);
    expect(good).toEqual([]);

    const noUrl = validateStepsForActivation([
      { step_type: 'send_webhook', step_config: {} },
    ]);
    expect(noUrl.map((i) => i.message)).toContain('webhook URL is required');

    const wrongProtocol = validateStepsForActivation([
      {
        step_type: 'send_webhook',
        step_config: { url: 'ftp://files.example.com' },
      },
    ]);
    expect(wrongProtocol.map((i) => i.message)).toContain(
      'webhook URL must use http or https'
    );

    const garbage = validateStepsForActivation([
      { step_type: 'send_webhook', step_config: { url: 'not a url' } },
    ]);
    expect(garbage.map((i) => i.message)).toContain(
      'webhook URL is not a valid URL'
    );
  });

  it("validates assign_conversation only when mode is 'specific'", () => {
    const roundRobinNoAgent = validateStepsForActivation([
      {
        step_type: 'assign_conversation',
        step_config: { mode: 'round_robin' },
      },
    ]);
    expect(roundRobinNoAgent).toEqual([]);

    const specificMissingAgent = validateStepsForActivation([
      { step_type: 'assign_conversation', step_config: { mode: 'specific' } },
    ]);
    expect(specificMissingAgent.map((i) => i.path)).toEqual([
      'steps[0].agent_id',
    ]);
  });

  it('flags create_deal when required fields are missing', () => {
    const issues = validateStepsForActivation([
      { step_type: 'create_deal', step_config: {} },
    ]);
    expect(issues.map((i) => i.path).sort()).toEqual([
      'steps[0].pipeline_id',
      'steps[0].stage_id',
      'steps[0].title',
    ]);
  });

  it('validates send_buttons / send_list interactive payloads', () => {
    const good = validateStepsForActivation([
      {
        step_type: 'send_buttons',
        step_config: {
          kind: 'buttons',
          body: 'Pick one',
          buttons: [{ id: 'yes', title: 'Yes' }],
        },
      },
    ]);
    expect(good).toEqual([]);

    const tooMany = validateStepsForActivation([
      {
        step_type: 'send_buttons',
        step_config: {
          kind: 'buttons',
          body: 'Pick one',
          buttons: [
            { id: 'a', title: 'A' },
            { id: 'b', title: 'B' },
            { id: 'c', title: 'C' },
            { id: 'd', title: 'D' },
          ],
        },
      },
    ]);
    expect(tooMany.map((i) => i.path)).toEqual(['steps[0].interactive']);
  });

  it('flags update_contact_field when field or value is missing', () => {
    const issues = validateStepsForActivation([
      { step_type: 'update_contact_field', step_config: { field: 'name' } },
      {
        step_type: 'update_contact_field',
        step_config: { field: '', value: 'x' },
      },
    ]);
    expect(issues.map((i) => i.path)).toEqual([
      'steps[0].value',
      'steps[1].field',
    ]);
  });

  it('recursively walks condition branches with stable dot-paths', () => {
    const issues = validateStepsForActivation([
      {
        step_type: 'condition',
        step_config: { subject: 'tag', operand: 'vip' },
        branches: {
          yes: [{ step_type: 'add_tag', step_config: { tag_id: '' } }],
          no: [
            {
              step_type: 'send_message',
              step_config: { text: '' },
            },
          ],
        },
      },
    ]);
    expect(issues.map((i) => i.path)).toEqual([
      'steps[0].yes.steps[0].tag_id',
      'steps[0].no.steps[0].text',
    ]);
  });

  it('reports an issue for unknown step types', () => {
    const issues = validateStepsForActivation([
      { step_type: 'do_a_barrel_roll', step_config: {} },
    ]);
    expect(issues).toEqual([
      { path: 'steps[0]', message: 'unknown step type: do_a_barrel_roll' },
    ]);
  });

  it('flags condition subject/operand independently', () => {
    const issues = validateStepsForActivation([
      { step_type: 'condition', step_config: {} },
    ]);
    expect(issues.map((i) => i.path).sort()).toEqual([
      'steps[0].operand',
      'steps[0].subject',
    ]);
  });
});

describe('semantic-only template validation', () => {
  it('accepts identity without cached metadata', () => {
    expect(
      validateStepsForActivation([
        {
          step_type: 'send_template',
          step_config: { template_id: '11111111-1111-1111-1111-111111111111' },
        },
      ])
    ).toEqual([]);
  });
  it.each(['variable_mappings', 'variables'])(
    'rejects %s even with a valid identity',
    (field) => {
      expect(
        validateStepsForActivation([
          {
            step_type: 'send_template',
            step_config: {
              template_id: '11111111-1111-1111-1111-111111111111',
              [field]: null,
            },
          },
        ])
      ).toEqual([expect.objectContaining({ path: `steps[0].${field}` })]);
    }
  );
});

describe('WhatsApp connection activation dependency', () => {
  const addTag = [{ step_type: 'add_tag', step_config: { tag_id: 'tag-1' } }];
  const sendTemplate = [
    {
      step_type: 'send_template',
      step_config: { template_name: 'welcome' },
    },
  ];

  it('allows CRM-only contact and PMS automations with no WhatsApp connection', () => {
    expect(validateTriggerForActivation('new_contact_created', {})).toEqual([]);
    expect(validateTriggerForActivation('reservation_confirmed', {})).toEqual(
      []
    );
    expect(validateStepsForActivation(addTag)).toEqual([]);
    expect(validateWhatsAppConnectionForActivation(addTag, null)).toEqual([]);
  });

  it('requires a connection for WhatsApp send actions, including nested branches', () => {
    expect(validateWhatsAppConnectionForActivation(sendTemplate, null)).toEqual(
      [
        {
          path: 'whatsapp_config_id',
          message:
            'a WhatsApp connection is required for WhatsApp send actions',
        },
      ]
    );
    expect(
      stepsRequireWhatsAppConnection([
        {
          step_type: 'condition',
          step_config: { subject: 'tag', operand: 'vip' },
          branches: { yes: sendTemplate, no: addTag },
        },
      ])
    ).toBe(true);
  });

  it('allows a valid selected connection for send-template automations', () => {
    expect(
      validateWhatsAppConnectionForActivation(sendTemplate, 'connection-1')
    ).toEqual([]);
  });
});

describe('validateTriggerForActivation', () => {
  it('accepts a valid keyword_match config', () => {
    expect(
      validateTriggerForActivation('keyword_match', {
        keywords: ['hello', 'hi'],
        match_type: 'exact',
      })
    ).toEqual([]);
  });

  it('rejects keyword_match with empty keyword array', () => {
    const issues = validateTriggerForActivation('keyword_match', {
      keywords: [],
      match_type: 'exact',
    });
    expect(issues.map((i) => i.path)).toContain('trigger.keywords');
  });

  it('rejects keyword_match with whitespace-only entries', () => {
    const issues = validateTriggerForActivation('keyword_match', {
      keywords: ['hi', '   '],
      match_type: 'contains',
    });
    expect(issues.map((i) => i.message)).toContain(
      'keywords cannot be empty strings'
    );
  });

  it('rejects keyword_match with an unknown match_type', () => {
    const issues = validateTriggerForActivation('keyword_match', {
      keywords: ['hi'],
      match_type: 'fuzzy',
    });
    expect(issues.map((i) => i.path)).toContain('trigger.match_type');
  });

  it('accepts keyword_match with a missing match_type (defaults to contains)', () => {
    expect(
      validateTriggerForActivation('keyword_match', { keywords: ['hi'] })
    ).toEqual([]);
  });

  it('accepts the word match_type (issue #409)', () => {
    // Activation validation has to stay in step with the engine and the
    // builder's dropdown — an automation the UI can save must not be
    // rejected on activation.
    expect(
      validateTriggerForActivation('keyword_match', {
        keywords: ['hi'],
        match_type: 'word',
      })
    ).toEqual([]);
  });

  it('requires schedule on time_based triggers', () => {
    expect(validateTriggerForActivation('time_based', {})).toEqual([
      { path: 'trigger.schedule', message: 'schedule is required' },
    ]);
    expect(
      validateTriggerForActivation('time_based', { schedule: '0 9 * * *' })
    ).toEqual([]);
  });

  it('requires tag_id on tag_added triggers', () => {
    expect(validateTriggerForActivation('tag_added', {})).toEqual([
      { path: 'trigger.tag_id', message: 'tag is required' },
    ]);
    expect(
      validateTriggerForActivation('tag_added', { tag_id: 'tag-uuid' })
    ).toEqual([]);
  });

  it('requires reply_ids on interactive_reply triggers', () => {
    expect(validateTriggerForActivation('interactive_reply', {})).toEqual([
      {
        path: 'trigger.reply_ids',
        message: 'at least one reply id is required',
      },
    ]);
    expect(
      validateTriggerForActivation('interactive_reply', {
        reply_ids: ['yes', 'no'],
      })
    ).toEqual([]);
    const empties = validateTriggerForActivation('interactive_reply', {
      reply_ids: ['yes', '  '],
    });
    expect(empties.map((i) => i.message)).toContain(
      'reply ids cannot be empty strings'
    );
  });

  it('does not flag unknown trigger types (handled elsewhere)', () => {
    expect(validateTriggerForActivation('some_future_trigger', {})).toEqual([]);
  });
});

describe('PMS property timezone activation validation', () => {
  it('accepts a scheduled trigger when targeted properties have timezones', async () => {
    await expect(
      validatePmsPropertyTimezonesForActivation(
        propertyDb([
          {
            id: 'property-a',
            name: 'Lakeside',
            timezone: 'Asia/Kolkata',
            status: 'active',
          },
          {
            id: 'property-b',
            name: 'Dubai Villa',
            timezone: 'Asia/Dubai',
            status: 'active',
          },
        ]),
        'account-1',
        'checkin_day',
        { local_time: '10:00' }
      )
    ).resolves.toEqual([]);
  });

  it('blocks activation rather than silently guessing a missing property timezone', async () => {
    const issues = await validatePmsPropertyTimezonesForActivation(
      propertyDb([
        {
          id: 'property-a',
          name: 'Lakeside',
          timezone: null,
          status: 'active',
        },
      ]),
      'account-1',
      'before_checkin',
      { local_time: '10:00', days_before: 1 }
    );
    expect(issues[0]).toMatchObject({ path: 'trigger.property_ids' });
    expect(issues[0].message).toContain('Lakeside');
  });

  it('preserves a valid legacy automation-level timezone', async () => {
    await expect(
      validatePmsPropertyTimezonesForActivation(
        propertyDb([]),
        'account-1',
        'after_checkout',
        { timezone: 'Asia/Kolkata', local_time: '10:00', days_after: 1 }
      )
    ).resolves.toEqual([]);
  });
});
