import { describe, it, expect } from 'vitest';
import {
  matchesContactFilters,
  matchesConnectionFilter,
  normalizeConversation,
} from './conversations';
import type { Conversation } from '@/types';

function makeConversation(
  contact: Partial<Conversation['contact']> | null
): Conversation {
  return {
    id: 'c1',
    user_id: 'u1',
    contact_id: 'ct1',
    status: 'open',
    unread_count: 0,
    created_at: '',
    updated_at: '',
    contact: contact
      ? {
          id: 'ct1',
          user_id: 'u1',
          account_id: 'a1',
          phone: '123',
          created_at: '',
          updated_at: '',
          ...contact,
        }
      : undefined,
  };
}

describe('matchesConnectionFilter', () => {
  const a = { ...makeConversation(null), whatsapp_config_id: 'a' };
  const b = { ...makeConversation(null), id: 'c2', whatsapp_config_id: 'b' };

  it('supports all and individual connection filters', () => {
    expect(
      [a, b].filter((row) => matchesConnectionFilter(row, 'all'))
    ).toHaveLength(2);
    expect([a, b].filter((row) => matchesConnectionFilter(row, 'a'))).toEqual([
      a,
    ]);
    expect([a, b].filter((row) => matchesConnectionFilter(row, 'b'))).toEqual([
      b,
    ]);
  });
});

const tag = (id: string, name = id) => ({
  id,
  user_id: 'u1',
  name,
  color: '#fff',
  created_at: '',
});

describe('matchesContactFilters', () => {
  it('matches everything when no filters are set', () => {
    const conv = makeConversation({ company: 'Acme', tags: [tag('t1')] });
    expect(matchesContactFilters(conv, { tagIds: [], company: null })).toBe(
      true
    );
    expect(makeConversation(null)).toBeDefined();
    expect(
      matchesContactFilters(makeConversation(null), {
        tagIds: [],
        company: null,
      })
    ).toBe(true);
  });

  it('uses OR logic across tags', () => {
    const conv = makeConversation({ tags: [tag('t1'), tag('t2')] });
    expect(
      matchesContactFilters(conv, { tagIds: ['t2', 't9'], company: null })
    ).toBe(true);
    expect(matchesContactFilters(conv, { tagIds: ['t9'], company: null })).toBe(
      false
    );
  });

  it('excludes conversations whose contact has no tags when a tag filter is active', () => {
    const conv = makeConversation({ tags: [] });
    expect(matchesContactFilters(conv, { tagIds: ['t1'], company: null })).toBe(
      false
    );
    expect(
      matchesContactFilters(makeConversation(null), {
        tagIds: ['t1'],
        company: null,
      })
    ).toBe(false);
  });

  it('matches company exactly, trimming whitespace', () => {
    const conv = makeConversation({ company: '  Acme  ' });
    expect(matchesContactFilters(conv, { tagIds: [], company: 'Acme' })).toBe(
      true
    );
    expect(matchesContactFilters(conv, { tagIds: [], company: 'Other' })).toBe(
      false
    );
  });

  it('requires both tag and company to match when both are set (AND across facets)', () => {
    const conv = makeConversation({ company: 'Acme', tags: [tag('t1')] });
    expect(
      matchesContactFilters(conv, { tagIds: ['t1'], company: 'Acme' })
    ).toBe(true);
    expect(
      matchesContactFilters(conv, { tagIds: ['t1'], company: 'Other' })
    ).toBe(false);
    expect(
      matchesContactFilters(conv, { tagIds: ['tX'], company: 'Acme' })
    ).toBe(false);
  });
});

describe('normalizeConversation', () => {
  it('flattens embedded contact_tags into contact.tags', () => {
    const raw = {
      id: 'c1',
      user_id: 'u1',
      contact_id: 'ct1',
      status: 'open' as const,
      unread_count: 0,
      created_at: '',
      updated_at: '',
      contact: {
        id: 'ct1',
        user_id: 'u1',
        account_id: 'a1',
        phone: '123',
        created_at: '',
        updated_at: '',
        contact_tags: [{ tags: tag('t1', 'VIP') }, { tags: null }],
      },
    };
    const normalized = normalizeConversation(raw);
    expect(normalized.contact?.tags).toEqual([tag('t1', 'VIP')]);
    // The raw join key is dropped from the flattened contact.
    expect(
      (normalized.contact as unknown as Record<string, unknown>).contact_tags
    ).toBeUndefined();
  });

  it('passes through a conversation with no contact', () => {
    const raw = {
      id: 'c1',
      user_id: 'u1',
      contact_id: 'ct1',
      status: 'open' as const,
      unread_count: 0,
      created_at: '',
      updated_at: '',
      contact: null,
    };
    // A contactless row passes through untouched (consumers use `?.`).
    expect(normalizeConversation(raw).contact).toBeNull();
  });
});
